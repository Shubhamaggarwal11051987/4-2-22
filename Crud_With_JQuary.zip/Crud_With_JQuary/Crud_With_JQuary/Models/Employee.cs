﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Crud_With_JQuary.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public int Email { get; set; }
        public int Mobile { get; set; }
        public int Image { get; set; }
        public bool Isactive { get; set; }
    }
}
