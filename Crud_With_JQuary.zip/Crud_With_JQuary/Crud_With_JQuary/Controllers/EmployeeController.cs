﻿using Crud_With_JQuary.Repositary.Contract;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud_With_JQuary.Controllers
{
    //[Authorize]
    public class EmployeeController : Controller
    {
        private IEmployee EmployeeService;
        public EmployeeController(IEmployee employees)
        {
            EmployeeService = employees;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetEmployees()
        {
            var emps = EmployeeService.GetEmployees();
            return Json(emps);
        }
    }
}
