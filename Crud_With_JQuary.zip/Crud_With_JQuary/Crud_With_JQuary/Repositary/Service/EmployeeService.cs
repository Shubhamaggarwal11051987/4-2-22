﻿using Crud_With_JQuary.Models;
using Crud_With_JQuary.Repositary.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud_With_JQuary.Repositary.Service
{
    public class EmployeeService : IEmployee
    {
        private readonly ApplicationDBcontxt dbcontext;
        public EmployeeService(ApplicationDBcontxt _dbcontext)
        {
            dbcontext = _dbcontext;
        }
        public List<Employee> GetEmployees()
        {
            return dbcontext.Employees.ToList();
        }
    }
}
