﻿using Crud_With_JQuary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Crud_With_JQuary.Repositary.Contract
{
    public interface IEmployee
    {
        List<Employee> GetEmployees();
    }
}
