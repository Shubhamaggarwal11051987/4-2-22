﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommanLayer.Models
{
  public  class ApplicationDbConfig
    {
        public static string DbConnection { get; set; }
    }
}
