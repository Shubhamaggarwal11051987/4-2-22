﻿using System;

namespace BusinessAccessLayer
{
    public class Class1
    {
    }
}
