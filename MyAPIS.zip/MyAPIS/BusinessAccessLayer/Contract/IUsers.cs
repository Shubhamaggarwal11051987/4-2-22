﻿using CommanLayer.Contracts.Request;
using CommanLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessAccessLayer.Contract
{
   public interface IUsers
    {
        public Users LoginUser(LoginModel model);
        public Users SignUpUser(Users model);

    }
}
