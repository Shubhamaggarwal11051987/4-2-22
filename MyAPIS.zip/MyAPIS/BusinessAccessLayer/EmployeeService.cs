﻿using DataAccessLayer;
using MyAPIS.Models;
using MyAPIS.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyAPIS.Respository
{
    public class EmployeeService : IEmployee
    {
        private readonly EmployeeDataOperation dataOperation;

        public EmployeeService()
        {
            this.dataOperation = new EmployeeDataOperation() ;
        }
        public Employees CreateEmployee(Employees emp)
        {
            var result= dataOperation.CreateEmployee(emp);
            return result;
        }

        public bool DeleteEmployee(int id)
        {
            var emp = dataOperation.DeleteEmployee(id);
            return emp;
        }

        public Employees GetEmployeeById(int id)
        {
            var emp = dataOperation.GetEmployeeById(id);
            return emp;
        }

        public List<Employees> GetEmployees()
        {
            var emps = dataOperation.GetEmployees();
            return emps;
        }

        public Employees UpdateEmployee(Employees model)
        {
            var result = dataOperation.UpdateEmployee(model);
            return result;
        }
    }
}
