﻿using BusinessAccessLayer.Contract;
using CommanLayer.Contracts.Request;
using CommanLayer.Models;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessAccessLayer
{
    public class UserService : IUsers
    {
        private UserOperation userOperation;

        public UserService()
        {
            userOperation = new UserOperation();
        }
        public Users LoginUser(LoginModel model)
        {
            return userOperation.SignInUser(model);
        }

        public Users SignUpUser(Users model)
        {
            return userOperation.SignUp(model);
        }
    }
}
