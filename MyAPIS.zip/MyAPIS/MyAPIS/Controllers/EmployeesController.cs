﻿using Microsoft.AspNetCore.Mvc;
using MyAPIS.Contracts.Response;
using MyAPIS.Models;
using MyAPIS.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyAPIS.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployee employeeService;

        public EmployeesController(IEmployee employeeService)
        {
            this.employeeService = employeeService;
        }
        [HttpGet]
        public IActionResult Get()
        {
            var emps = employeeService.GetEmployees();
            var response = new ApiResponse();
            if (emps.Count == 0)
            {
                response.data = emps;
                response.error = "employees not found !";
                response.status = 404;
                response.message = "Employee record not avialable !";

                return NotFound(response);
            }
            else
            {
                response.data = emps;
                response.status = 200;
                response.message = "Employee record found !";
                return Ok(response);
            }
        }


        [HttpGet]
        [Route("getemployeebyid/{id}")]
        public IActionResult Get(int id)
        {
            var emps = employeeService.GetEmployeeById(id);
            var response = new ApiResponse();
            if (emps == null)
            {
                response.data = emps;
                response.status = 404;
                response.message = $"Employee record with {id} not found !";
                response.error = "Invalid employee id !";
                return NotFound(response);
            }
            else
            {
                response.data = emps;
                response.status = 200;
                response.message = $"Employee record with {id}  found !";
                return Ok(response);
            }
        }
        [HttpPost]
        public IActionResult Post(Employees employee)
        {
            if (employee ==null)
            {
                return BadRequest();
            }
            else
            {
               var result= employeeService.CreateEmployee(employee);
                return Created("Get", result);
            }
        }

        [HttpDelete]
        [Route("delete/{id}")]
        public IActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            else
            {
               var result= employeeService.DeleteEmployee(id);
                if(result)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound();
                }
            }
        }


    }
}
