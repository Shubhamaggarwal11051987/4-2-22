﻿using BusinessAccessLayer.Contract;
using CommanLayer.Contracts.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyAPIS.Contracts.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyAPIS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IUsers userService;

        public AuthenticationController(IUsers userService)
        {
            this.userService = userService;
        }

        [HttpPost]
        [Route("signin")]
        public IActionResult SignIn(LoginModel model)
        {
            var response = new ApiResponse();
            if (ModelState.IsValid)
            {
               var result= userService.LoginUser(model);
                if (result != null)
                {
                    response.data = result;
                    response.status = 200;
                    response.message = "Login Successfull !";
                    response.token = "akjsfhaksfasfas";
                    return Ok(response);

                }
                else
                {
                    response.data = result;
                    response.status = 404;
                    response.message = "Login Failed !";
                    response.error = "Invalid login email or password !";
                    return Ok(response);
                }
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
