﻿using MyAPIS.Models;
using MyAPIS.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyAPIS.Respository
{
    public class EmployeeService : IEmployee
    {
        private readonly ApplicationDbContext dbContext;

        public EmployeeService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public Employees CreateEmployee(Employees emp)
        {
            dbContext.Employees.Add(emp);
            dbContext.SaveChanges();
            return emp;
        }

        public bool DeleteEmployee(int id)
        {
            var emp = dbContext.Employees.SingleOrDefault(e => e.Id == id);
            if (emp == null)
            {
                return false;
            }
            else
            {
                dbContext.Employees.Remove(emp);
                dbContext.SaveChanges();
                return true;
            }
        }

        public Employees GetEmployeeById(int id)
        {
            var emp = dbContext.Employees.SingleOrDefault(e => e.Id == id);
            return emp;
        }

        public List<Employees> GetEmployees()
        {
            return dbContext.Employees.ToList();
        }

        public Employees UpdateEmployee(Employees model)
        {
            dbContext.Employees.Update(model);
            dbContext.SaveChanges();
            return model;
        }
    }
}
