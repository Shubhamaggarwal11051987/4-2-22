﻿using CommanLayer.Contracts.Request;
using CommanLayer.Models;
using MyAPIS.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DataAccessLayer
{
  public  class UserOperation
    {
        private ApplicationDbContext dbContext;
        public UserOperation()
        {
            dbContext = new ApplicationDbContext();
        }

        public Users SignInUser(LoginModel model)
        {
            var user = dbContext.Users.SingleOrDefault(e => e.Email == model.Email && e.Password == model.Password);
            return user;
        }

        public Users SignUp(Users model)
        {
            dbContext.Users.Add(model);
            dbContext.SaveChanges();
            return model;
        }

    }
}
