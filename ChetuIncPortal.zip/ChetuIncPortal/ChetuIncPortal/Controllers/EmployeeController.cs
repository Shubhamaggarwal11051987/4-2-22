﻿using BusinessAcessLayer.Contract;
using CommanLayer.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChetuIncPortal.Controllers
{
    public class EmployeeController : Controller
    {
        private IEmployee employeeService;
        public EmployeeController(IEmployee employee) {
            employeeService = employee;
        }
        public IActionResult Index()
        {
            var emps = employeeService.GetEmployees();
            return View(emps);
        }

        public IActionResult Create()
        {
            return View();
        } 
        
        [HttpPost]
        public IActionResult Create(Employees employee)
        {
            var result=employeeService.CreateEmployee(employee);
            if (result != null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(String.Empty, "Something went wrong !");
                return View();
            }
        }

        public IActionResult Delete(int id)
        {
            var r = employeeService.DeleteEmployee(id);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var r = employeeService.GetEmployeeById(id);
            return View(r);
        }  
        
        [HttpPost]
        public IActionResult Edit(Employees emp)
        {
            var r = employeeService.UpdateEmployee(emp);
            if (r != null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(String.Empty, "Something went wrong !");
                return View();
            }
        }
    }
}
