﻿using BusinessAcessLayer.Contract;
using CommanLayer.Models;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessAcessLayer.Service
{
    public class EmployeeService:IEmployee
    {
        private EmployeeDataOperation employeeDb;
        public EmployeeService()
        {
            employeeDb = new EmployeeDataOperation();
        }

        public Employees CreateEmployee(Employees emp)
        {
            var result = employeeDb.Create(emp);
            return result;
        }

        public bool DeleteEmployee(int id)
        {
            var result = employeeDb.Delete(id);
            return result;
        }

        public Employees GetEmployeeById(int id)
        {
            var result = employeeDb.GetEmployeeById(id);
            return result;
        }

        public List<Employees> GetEmployees()
        {
            return employeeDb.GetEmployees();
        }

        public Employees UpdateEmployee(Employees emp)
        {
            var result = employeeDb.UpdateEmployee(emp);
            return result;
        }
    }
}
