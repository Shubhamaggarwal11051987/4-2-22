﻿using CommanLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.SqlClient;
using Microsoft.Data;
using System.Data;
namespace DataAccessLayer
{
   public class EmployeeDataOperation
    {
        private DbConnect connect;
        public EmployeeDataOperation()
        {
            connect = new DbConnect();
        }

        public Employees Create(Employees emp)
        {
            SqlCommand cmd = new SqlCommand("Sp_Employee", connect.connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "CREATE");
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@email", emp.Email);
            cmd.Parameters.AddWithValue("@mobile", emp.Mobile);
            cmd.Parameters.AddWithValue("@gender", emp.Gender);
            cmd.Parameters.AddWithValue("@isactive", emp.IsActive);
            cmd.Parameters.AddWithValue("@image", emp.Image);

            if (connect.connection.State == ConnectionState.Closed)
            {
                connect.connection.Open();
            }
            int r =(int)cmd.ExecuteScalar();
            connect.connection.Close();
            if (r == 1)
            {
                return emp;
            }
            else
            {
                return null;
            }

        }

        public bool Delete(int id)
        {
            SqlCommand cmd = new SqlCommand("Sp_Employee", connect.connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "DELETE");
            cmd.Parameters.AddWithValue("@id", id);       

            if (connect.connection.State == ConnectionState.Closed)
            {
                connect.connection.Open();
            }
            int r = (int)cmd.ExecuteScalar();
            connect.connection.Close();
            if (r == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Employees GetEmployeeById(int id)
        {
            SqlCommand cmd = new SqlCommand("Sp_Employee", connect.connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "SELECT_SINGLE");
            cmd.Parameters.AddWithValue("@id", id);
          
            if (connect.connection.State == ConnectionState.Closed)
            {
                connect.connection.Open();
            }
           SqlDataReader dr= cmd.ExecuteReader();

            dr.Read();
            Employees emp = new Employees()
            {
                Id = (int)dr["ID"],
                Name = dr["NAME"].ToString(),
                Email = dr["EMAIL"].ToString(),
                Mobile = dr["MOBILE"].ToString(),
                Gender = dr["GENDER"].ToString(),
                IsActive = (bool)dr["ISACTIVE"],
                Image = dr["IMAGE"].ToString(),
                Create_On = (DateTime)dr["CREATED_ON"],

            };
            connect.connection.Close();
            return emp;

        }
        public Employees UpdateEmployee(Employees emp)
        {
            SqlCommand cmd = new SqlCommand("Sp_Employee", connect.connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "UPDATE");

            cmd.Parameters.AddWithValue("@ID", emp.Id);
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@email", emp.Email);
            cmd.Parameters.AddWithValue("@mobile", emp.Mobile);
            cmd.Parameters.AddWithValue("@gender", emp.Gender);
            cmd.Parameters.AddWithValue("@isactive", emp.IsActive);
            cmd.Parameters.AddWithValue("@image", emp.Image);

            if (connect.connection.State == ConnectionState.Closed)
            {
                connect.connection.Open();
            }
            int r = (int)cmd.ExecuteScalar();
            connect.connection.Close();
            if (r == 1)
            {
                return emp;
            }
            else
            {
                return null;
            }
        }

        public List<Employees> GetEmployees()
        {
            SqlCommand cmd = new SqlCommand("Sp_Employee", connect.connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@action", "SELECT");
            if (connect.connection.State == ConnectionState.Closed)
            {
                connect.connection.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            List<Employees> employees = new List<Employees>();
            while (dr.Read())
            {
                Employees emp = new Employees()
                {
                    Id = (int)dr["ID"],
                    Name = dr["NAME"].ToString(),
                    Email = dr["EMAIL"].ToString(),
                    Mobile = dr["MOBILE"].ToString(),
                    Gender = dr["GENDER"].ToString(),
                    IsActive = (bool)dr["ISACTIVE"],
                    Image = dr["IMAGE"].ToString(),
                    Create_On = (DateTime)dr["CREATED_ON"],

                };
                employees.Add(emp);
            }

            connect.connection.Close();
            return employees;
        }

    }
}
