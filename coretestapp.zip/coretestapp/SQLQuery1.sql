﻿select* from departments;
select* from employees;

insert into departments values
('IT'),
('HR'),
('SALES'),
('ADMIN'),
('ACCOUNT');

INSERT INTO EMPLOYEES VALUES
('AJAY','AJAY77@GMAIL.COM',19000,'MALE',1),
('RAHUL','RAHUL77@GMAIL.COM',69000,'MALE',5),
('MOHIT','MOHIT77@GMAIL.COM',89000,'MALE',2),
('SURAJ','SURAJ77@GMAIL.COM',29000,'MALE',1),
('VIJAY','VIJAY77@GMAIL.COM',39000,'MALE',3),
('KARAN','KARAN77@GMAIL.COM',49000,'MALE',4);

